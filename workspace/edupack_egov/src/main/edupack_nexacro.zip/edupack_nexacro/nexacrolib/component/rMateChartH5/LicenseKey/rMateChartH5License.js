// -----------------------------------------------------------------------------
// rMate Chart H5 License Key 
//
// Product Name : rMate Chart for HTML5 v6.0
// License Type : Enterprise Trial License
// Product No : 7AB6-65FB-BDA0-AE6Y
// Authenticated server Info : undefinde
// Expiration date : 2022/06/30
//
var rMateChartH5License = "4dff8db0a339d868bdc43356288b46397842bb86718f7cf00da02f8940e8f184:3500660b6248443a4f4220504c2056593a3632452e41302d2030504156443a42432d35422d4645354e362d2d36362e4230412d37453a564c41204c302033452f4c363a30742f203243323a303232303a32453220302a333a324839";
// -----------------------------------------------------------------------------
