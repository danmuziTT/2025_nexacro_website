﻿// // var _pApplication = nexacro.Application ; 
// _pApplication.trace = function (log, level) {
// 	alert("trace");
// };  
//     
// if (nexacro._Browser == "Runtime") {
// 	nexacro._trace = function () {
// 
// 	};
// 	trace = nexacro._trace; 
// } else {
// 	window.trace = function ()
// 	{
// 	} 
// } 
  